
var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange =function(){
if (this.readyState == 4 && this.status == 200) {
document.getElementById("lipstick-title").innerHTML = (product[0].title);
document.getElementById("lipstick-description").innerHTML = (product[0].desc);

document.getElementById("eyeshadow-title").innerHTML = (product[1].title);
document.getElementById("eyeshadow-description").innerHTML = (product[1].desc);

document.getElementById("nail-lacquer-title").innerHTML = (product[2].title);
document.getElementById("nail-lacquer-description").innerHTML =(product[2].desc);

document.getElementById("mineralize-skinfinish-title").innerHTML = (product[3].title);
document.getElementById("mineralize-skinfinish-description").innerHTML =(product[3].desc);

}
};
xmlhttp.open("GET", "json.json", true);
xmlhttp.send();
