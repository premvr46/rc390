$(function(){
$("#addit1").click(function(){
  var productName = $("#productName1").val();
  var data = {
    'product_name': productName
  };
  $.post("check.html", data, showDone);
 });
 
 var showDone = function() {
  /* Make something happen here*/
  document.write( $("#productName1").val());
  /*document.write('<button id="mybutton" onclick ="window.location='indexht.html';">Button</button>');*/
 }
 
});

  $(function(){
 $("#addit2").click(function(){
  var productName = $("#productName2").val();
  var data = {
    'product_name': productName
  };
  $.post("check.html", data, showDone);
 });
 
 var showDone = function() {
  /* Make something happen here*/
  document.write( $("#productName2").val());
 }
  });
  
  $(function(){
 $("#addit3").click(function(){
  var productName = $("#productName3").val();
  var data = {
    'product_name': productName
  };
  $.post("check.html", data, showDone);
 });
 
 var showDone = function() {
  /* Make something happen here*/
  document.write( $("#productName3").val());
 }
  });
  
  $(function(){
 $("#addit4").click(function(){
  var productName = $("#productName4").val();
  var data = {
    'product_name': productName
  };
  $.post("check.html", data, showDone);
 });
 
 var showDone = function() {
  /* Make something happen here*/
  document.write( $("#productName4").val());
 }
 
});