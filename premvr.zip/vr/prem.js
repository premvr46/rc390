
 
var halley = { 
     "product" :[
            
			{"title":"LIPSTICK","desc":"color plus texture for the lips that made M-A-C famous.limited-edition shade of sounds like noise a true bright orange inspired by hayley williams $15.00"},
			{"title":"EYE SHADOW","desc":"A highly-pigmented powder in a mid-tone coral with a frost finish inspired by hayley williams.Applies evenly,blends well.Limited edition $15.00"},
			{"title":"NAIL LACQUER","desc":"High gloss,cream formula in Hayley's signature color,a true bright orange.provides no-streak/no-chip finish.Contains conditioners and UV protection.Limited edition $16.00"},
			{"title":"MINERALIZE SKINFINISH","desc":"A luxurious velvet-soft powder with high-frost metallic finish.Smoothes on,adds buffed-up highlights to cheeks,or an overall ultra-deluxe polish to the face.$29.00"}
			
			]
		}
			

document.getElementById("lipstick-title").innerHTML = halley.product[0].title;
document.getElementById("lipstick-description").innerHTML =halley.product[0].desc;
document.getElementById("eyeshadow-title").innerHTML = halley.product[1].title;
document.getElementById("eyeshadow-description").innerHTML = halley.product[1].desc;
document.getElementById("nail-lacquer-title").innerHTML =halley.product[2].title;
document.getElementById("nail-lacquer-description").innerHTML =halley.product[2].desc;
document.getElementById("mineralize-skinfinish-title").innerHTML = halley.product[3].title;
document.getElementById("mineralize-skinfinish-description").innerHTML =halley.product[3].desc;
